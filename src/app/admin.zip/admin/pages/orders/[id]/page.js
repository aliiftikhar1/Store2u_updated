import AdminOrdersPage from '../AdminOrdersPage';

const OrderDetailsPage = () => {
  return (
    <div className="bg-white min-h-screen">
      <AdminOrdersPage />
    </div>
  );
};

export default OrderDetailsPage;
